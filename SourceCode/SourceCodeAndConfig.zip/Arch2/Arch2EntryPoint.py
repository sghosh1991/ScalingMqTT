import Controller_Simple


def start():
    
    """
    This function is the entry point for architecture 1. Currently it consists of
    a single broker which runs on local host behind a load balancer. 
    the assumption is that the load balancer runs on localhost on port 1234.
    Configure the load balancer as per the config file given in Arch2 directory.
    
    Assumptions:
    1. Two brokers running on port 2000 and 2001 form the broker cluster.
    2. HAProxy running on localhost on port 1234.
    3. The brokers can run on a different IP.In that case edit the haproxy.cfg file
    
    """
    
    #define broker parameters to connect to
    broker_params = ("Controller" , "localhost", 1234)
    
    #define the controller which connects to the broker defined by
    #broker parameters
    controller = Controller_Simple(broker_params)
    
    #start the controller n/w loop
    controller.start_controller()
    
if __name__ == "__main__":

    start()
