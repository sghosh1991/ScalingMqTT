"""
This module is responsible for collecting the stats on the consumer side.
Specifically it measures the message latency and the message loss. To use this
module simply run it with python ConsumerStatsCollector.py

Assumption: The broker runs on the localhost
If not please update the BROKER_IP and then run.

Output:

This module will keep on dumping the messages received in  a loop.

"""

import paho.mqtt.client as mqtt
import time, threading, logging


BROKER_IP = "localhost"

"""
The IP of the broker
"""
BROKER_PORT=1234

CLIENT_DATA_TOPIC = "data/+"

"""
The topic that the consumer must subscribe to inorder to get the messages
"""

#logging.basicConfig(level=logging.DEBUG,format='[%(levelname)s] (%(threadName)-10s) %(message)s',)

avgLatency = dict()

def on_client_data_received(client, userdata, message):
    
    """
    Callback when the consumer receives messages
    """
    
    curr_time = time.time()
    clientID = message.topic[5:]
    #messageID = message.payload.split(":")[0]
    publishTime = float(message.payload.split(":")[1])
    latency = curr_time - publishTime
    
    
    if(clientID in avgLatency):
        
        numMessages = avgLatency[clientID][0]
        mean_latency = (latency + numMessages * avgLatency[clientID][1])/(numMessages + 1)
        avgLatency[clientID] = (numMessages + 1, mean_latency)
    else:
        
        avgLatency[clientID] = (1,latency)
    
    print ("In consumer")
    
    totalMessages = 0
    totalLatency = 0.0
    
    for clients,info in avgLatency.items():
        
        totalMessages = totalMessages + (int)(info[0])
        totalLatency = totalLatency + (float)(info[1])
    
    #if (len(avgLatency) > 10):
        
    print("Total clients = " + str(len(avgLatency)))
    print("Total message rcvd: " + str(totalMessages))
    print("Total message rcvd: " + str(totalLatency/1000))
        
        
    
    
def on_consumer_connect(a,b,c):
    print ("consumer connected")

def on_consumer_disconnect(a,b,c):
    print ("Consumer Disconnected")


if __name__ == "__main__":
    
    consumer = mqtt.Client("Consumer" ,clean_session=False , userdata=None)
    
    consumer.connect(BROKER_IP, BROKER_PORT, 60)
    
    consumer.on_connect = on_consumer_connect
    consumer.on_disconnect = on_consumer_disconnect
    
    consumer.subscribe(CLIENT_DATA_TOPIC, 2)
    consumer.message_callback_add(CLIENT_DATA_TOPIC, on_client_data_received)
    
    #start n/w loop in a bg thread
    consumer.loop_start()
    
    #wait forever
    while 1:
        pass


        


    
    