import paho.mqtt.client as mqtt

(CLIENT_ID,BROKER_IP,BROKER_PORT) = (0,1,2)

class MqttClient():
    
    """
    This class is a wrapper class that models a Mqtt client. It contains functionality for
    connecting to the broker, subscribing for messages, publishing messages and 
    registering appropriate callbacks.
    
    """
    
    mqtt_client = ""
    kafkaConsumerHandle = ""
    kafkaProducerHandle = ""
    clientID = ""
    
    
    def __init__(self,connect_params, kafkaProducerHandle, kafkaConsumerHandle):
        
        """
        This is the constructor that initializes the mqtt client. 
        @param connect_params: A List containing the parameters for connecting. Format is
                                (CLIENT_ID,BROKER_IP,BROKER_PORT)
        
        @param kafkaProducerHandle: The kafka producer client. Hybrid clients use it for
                                    pushing data messages from mqtt broker to kafka cluster. Controller_Arch3 Agent
                                    uses the producer to push control messages to the kafka cluster.
                                    
        @param kafkaConsumerHandle: The kafka consumer client. Hybrid clients use it for
                                    consuming control messages from kafka cluster. Controller_Arch3 Agent
                                    uses the producer to consume data messages from the kafka cluster.
        
        """

        self.clientID = connect_params[CLIENT_ID]
        self.mqtt_client = mqtt.Client(connect_params[CLIENT_ID],clean_session=False , userdata=None)
        self.kafkaConsumerHandle = kafkaConsumerHandle
        self.kafkaProducerHandle = kafkaProducerHandle
        
        
        self.mqtt_client.connect(connect_params[BROKER_IP], connect_params[BROKER_PORT], 60)
        
        self.mqtt_client.on_connect = self.on_connect
        self.mqtt_client.on_subscribe = self.on_subscribe
        self.mqtt_client.on_publish = self.on_publish
        self.mqtt_client.on_disconnect = self.on_disconnect
        
        
        self.mqtt_client.subscribe("data/+", 0)
        self.mqtt_client.message_callback_add("data/+", self.on_message_received)

        #print (" Mqtt client created " + str(self.clientID))
        
#         while 1:
#             pass
    
    def listenToUEessahes(self): 
        
        """
        This function spawns a background thread that runs the network loop for the client device.
        This loop handles all network i/o sending and listening for packets.
        
        """
        
        self.mqtt_client.loop_start
    
    def publishToBroker(self,topic,payload,qos,retain):
        
        """
        Publish the message to the broker with the given parameters.
        @param topic: The topic on which to publish
        @param payload: The message to send
        @param qos: The quality of service level to publish on.
        @param retain: If True the message will be reatained on the broker.
        """
        
        self.mqtt_client.publish(topic, payload, qos, retain)
    

    def on_connect(self,client, userdata, rc, a):
        
        """
        Callback for when the clients connection request is granted by the broker
        """
        
        print (str(client) + " with id " + self.clientID + " Connected")
        
    def on_publish(self,client, userdata, mid):
        
        """
        Call back for when the client publishes something to the broker and the broker acknowledges
        the receipt of the message sent.
        """
        
        print (str(self,client) + "on publish")
        
    def on_subscribe(self,client, userdata, mid, granted_qos):
        
        """
        Callback for the client's subscription. When the client subscribes for a topic on the broker
        and the broker acknowledges it , this method is fired.
        """
        
        print (str(client) + "subscribed")
    
    
    def on_disconnect(self,client, userdata, rc):
        
        print ("disconnected")
           
    
    def on_message_received(self,client, userdata, message):
        
        """
        Callback which is fired when the client device receives a message 
        """
        
        print (self.clientID + "Got message on topic " + message.topic)
        print (self.clientID + "Message payload " + message.payload)
        mac = message.topic.split("/")[1]
        
        #send data to kafka with topic data and message mac
        self.kafkaProducerHandle.send_messages(bytes("data"), bytes(mac))
    
    
   
if __name__ == "__main__":
    
    pass
