from kafka import KafkaClient, KeyedProducer, RoundRobinPartitioner, SimpleConsumer, SimpleProducer
import paho.mqtt.client as mqtt
import thread,time
from MqttClients import MqttClient
import ConsumerStats

class Controller():
    
    
    """
    This class represents the single Controller instance that is responsible for 
    controlling all the sensor devices. It has got two functions -> 1) to consume, from the 
    kafka cluster, all the messages sent by the sensor devices -> 2) Send control messages to
    the sensor devices asking them to give data. 
    
    """
    
    kafkaConsumerHandle = ""
    """
    """
    kafkaProducerHandle = ""
    """
    """
    kafka = ""
    """
    """
    mqtt_client_consumer = ""
    """
    """
    consumerGrup = "Consumer_Process"
    """
    """
    consumtionTopic = "data"
    """
    """
    
    controlMessageTopic = "Controller"
    
    """
    """
    
    uniqueUE = set()
    """
    """
    
    def __init__(self):
        
        """
        
        This is the controller constructor. It initializes the kafka clinet, kafka consumerhandle, kafka producer handle,
        the mqtt 
        
        """
        
        self.kafka = KafkaClient("localhost:9092")
        self.kafkaProducerHandle = SimpleProducer(self.kafka)
        self.kafkaConsumerHandle = SimpleConsumer(self.kafka,self.consumerGrup,self.consumtionTopic)
       
    
    
    def pullMessagesFromKafka(self):
        
        """
        The function will pull data messages from the kafka cluster. This message should be run on
        a background thread so that it does not block other functions of the system.
        """
  
        while True:
            
            #Sleep for a second to reduce the CPU usage
            time.sleep(1)
            s = self.kafkaConsumerHandle.get_messages(10, True, 0)
        
            if (len(s) > 0):
                
                self.uniqueUEs = set()
                
                print ("Got message from brokers")

                for m in s:
                    
                    self.uniqueUEs.add(str(m.message.value))
                    print (str(m.offset) + str(m.message.value))
            
                    #Generate the stats
                    ConsumerStats.generateStats(m.message.value)
                    ConsumerStats.generateStats()
            
            
    
    
    def sendControlMessage(self,message):
        
        """
        This function simply pushes the control message sent by the scheduler [schedule() function] to the broker.
        """
        
        self.kafkaProducerHandle.send_messages(bytes(self.controlMessageTopic), bytes(message))
        print("Message sent by controller: " + message);
        
    
    
    def schedule(self):
        
        """
        This function is a simple round-robin scheduler that asks for data from all the sensor devices.
        The function basically sends a command message to the kafka cluster by calling sendControlMessage(message) function. This command 
        message is consumed (pulled) by the hybrid clients and sent over to the broker, which then 
        pushes it to the respective sensor devices.
        
        """
        
        i = 0
        print ("Scheduling")
        
        while True:
            
            
            self.sendControlMessage("command/" + str(i) + ":" + "Hello" + str(i))
            i = i+1
            time.sleep(5)

if __name__ == "__main__":
    
    C = Controller()
    
    thread.start_new_thread(C.pullMessagesFromKafka(), ())
    
    
        