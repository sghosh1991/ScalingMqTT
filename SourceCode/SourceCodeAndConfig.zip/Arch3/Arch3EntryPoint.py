import HybridClients
import thread
import Controller_Arch3
import time


def start():
    
    
    """
    This function is the entry point for architecture 1. Currently it consists of
    a single broker which runs on local host behind a load balancer. 
    the assumption is that the load balancer runs on localhost on port 1234.
    Configure the load balancer as per the config file given in Arch2 directory.
    
    Constrains: 
    
    In this version I have used 2 brokers as my broker cluster.
    This is hard coded and the kafka cluster code (number of partitions in the "controller" topis) 
    also depends on the fact that only 2 brokers are there.
    This drawback can be easily removed by parameterizing the number of brokers and 
    the number of partitions for the "control" message topic in kafka cluster.
    
    Assumptions:
    1. Two brokers running on port 2000 and 2001 form the broker cluster.
    2. HAProxy running on localhost on port 1234.
    3. The brokers can run on a different IP.In that case edit the haproxy.cfg file
    4. Kafka cluster running on localhost on ports 9092. (If not change line 68 in HybridClients.py)
    5. Kafka topics and partitions are already set up
    
    """
    
    
    #Parameters that define connectivity to mqtt broker
    broker_params1 = ("HC_1" , "localhost", 1234)
    broker_params2 = ("HC_2" , "localhost", 1234)
    
    
    #Currently we are creating only two Hybrid Clients
    h1 = HybridClients(broker_params1,"HC_1",0)
    h2 = HybridClients(broker_params2, "HC_2",1)
    
    #Create a Controller Agent
    C = Controller_Arch3.Controller()
    
    #Spawn a thread that will continuosly pull data messages from Kafka
    thread.start_new_thread(C.pullMessagesFromKafka, ())  
    thread.start_new_thread(C.schedule,())
    
    
    #Spawn a thread that will enable the hybrid clients to pull control messages from Kafka Cluster
    thread.start_new_thread(h1.pullControlMessages,())
    thread.start_new_thread(h2.pullControlMessages,())

    while True:
        
        time.sleep(1)
        pass
    


if __name__ == "__main__":
    
    start()
    
    