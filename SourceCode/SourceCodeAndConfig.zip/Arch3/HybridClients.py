"""
This module contains class to handle the thin client
"""


from KafkaUtils import Kafka_Consumer, Kafka_Producer
from kafka import SimpleConsumer, KafkaClient, SimpleProducer
from MqttClients import MqttClient
import time,thread
import Controller_Arch3


(CLIENT_ID,BROKER_IP,BROKER_PORT) = (0,1,2)




class HybridClients():
    
    """"
    This class is represents the thin client layer that connects the Kafka to the Mqtt Broker. 
    """
    
    
    brokerHandle = None
    
    """
    The broker handle
    """
    
    
    kafkaProducerHandle = None
    """
    The kafka producer handle
    """
    
    
    kafkaConsumerHandle = None
    """
    The kafka consumer handle to push data to the kafka cluster
    """
    
    
    client_id = None
    """
    The client ID
    """
    
    
    partitonsToConsume = None
    """
    The partitionList to consume
    """
    
    
    
    def __init__(self,broker_params, client_id, partition_to_consume):
        
        """
        The init function
        
        """
        
        #client ID
        self.client_id = client_id
        self.partitonsToConsume = partition_to_consume
        
        #kafka producer/consumer handles
        client = KafkaClient('localhost:9092')
        self.kafkaProducerHandle = SimpleProducer(client)
        self.kafkaConsumerHandle = SimpleConsumer(client,"HC_Consumers","Controller_Arch3", partitions=[partition_to_consume])
        self.kafkaConsumerHandle.provide_partition_info()
        #mqtt handle
        self.brokerHandle = MqttClient(broker_params, self.kafkaProducerHandle, self.kafkaConsumerHandle)
        self.brokerHandle.listenToUEessahes()
        
        print ("created hc client " + self.client_id)
        
        #self.pullControlMessages()
    
    
    
    
    def pullControlMessages(self):
        
        """
        This function will pull the control messages sent by the Controller agent off the
        Kafka Cluster. The periodicity of pulling messages is 1 second.
        Since we have used a SimpleConsumer class from kafka as our consumer the
        control messages will be evenly distributed by the kafka cluster among the
        two hybridclients. This will reduce load on the hybrid clients and the 
        broker.
    
        """
        #loop infinitely for consuming:
        
        print (self.client_id + " consuming control messages") 
        
        while True:
            
            
            s = self.kafkaConsumerHandle.get_messages(10, True, 6)
            self.kafkaConsumerHandle.commit([self.partitonsToConsume])
        
            if (len(s) > 0):
                
                
                
                print (self.client_id + " got CONTROL message from controller")
                
                for p,m in s:
                    
                    print (str(p))
                    print (str(m.offset) + " : " + str(m.message.value))
                    topic = str(m.message.value).split(":")[0]
                    message = str(m.message.value).split(":")[1]
                    print ("Pushing data to brooker with topic " + topic + " and message: " + message)
                    
                    self.brokerHandle.publishToBroker(topic,message,2,False)
                    
                    
    
    
    
    
    
    
    
            
            