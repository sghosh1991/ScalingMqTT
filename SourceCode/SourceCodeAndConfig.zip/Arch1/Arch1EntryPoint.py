import Controller_Simple

def start():
    
    """
    This function is the entry point for architecture 1. Currently it consists of
    a single broker which runs on local host behind a load balancer. The load balance here 
    although of needed is given just for sake of uniformity with other architectures. 
    the assumption is that the load balancer runs on localhost on port 1234
    
    Assumptions:
    1. Single broker running on port 2000 or 2001
    2. HAProxy running on localhost on port 1234
    
    """
    
    #define broker parameters to connect to
    broker_params = ("Controller" , "localhost", 1234)
    
    #define the controller which connects to the broker defined by
    #broker parameters
    controller = Controller_Simple(broker_params)
    
    #start the controller n/w loop
    controller.start_controller()
    
if __name__ == "__main__":

    start()
