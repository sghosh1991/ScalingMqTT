"""
This module is responsible for collecting the stats on the consumer side.
Specifically it measures the message latency and the message loss. To use this
module simply run it with python ConsumerStatsCollector.py

Assumption: The broker runs on the localhost
If not please update the BROKER_IP and then run.

"""

import paho.mqtt.client as mqtt
import time, threading, logging
import ConsumerStats



#logging.basicConfig(level=logging.DEBUG,format='[%(levelname)s] (%(threadName)-10s) %(message)s',)

class Controller():
    
    controller = None
    
    def __init__(self,broker_params):
        
        self.controller = mqtt.Client(broker_params[0] ,clean_session=False , userdata=None)
        
        self.controller.connect(broker_params[1], broker_params[2], 60)
        
        self.controller.on_connect = self.on_consumer_connect
        self.controller.on_disconnect = self.on_consumer_disconnect
        
        self.controller.subscribe("data", 2)
        self.controller.message_callback_add("data", self.on_client_data_received)
        
        
        
    
    def start_controller(self):
        
        #start n/w loop in a bg thread
        self.controller.loop_start()
        
    
        

    def on_client_data_received(self,client, userdata, message):
        
        """
        Callback when the consumer receives messages
        """
        
        ConsumerStats.generateStats(message)
        ConsumerStats.generateStats()
        
    
        
    def on_consumer_connect(self,a,b,c):
        print ("Consumer connected")
    
    def on_consumer_disconnect(self,a,b,c):
        print ("Consumer Disconnected")
    
    
    if __name__ == "__main__":
        
        
        
        #wait forever
        while 1:
            time.sleep(.05)
            pass


        


    
    